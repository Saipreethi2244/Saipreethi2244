# NIBT Roll-up Dashboard

## Run it (PowerShell only - no admin rights needed)

    cd <folder with app.py>
    python -m venv .venv
    .\.venv\Scripts\Activate.ps1
    pip install -r requirements.txt
    python -m streamlit run app.py

Browser opens at http://localhost:8501.

If scripts are blocked:  Set-ExecutionPolicy -Scope Process Bypass
If you skip the venv:    pip install --user -r requirements.txt
If pip is blocked by a proxy: pip install -r requirements.txt --proxy http://user:pass@proxy:port
   (or ask IT for an internal PyPI mirror: --index-url <url>)

## Optional: read account numbers from images

    pip install -r requirements-ocr.txt

Without it, Excel / CSV / pasted text still work; images show a notice.
Always check the "Review / correct extracted account numbers" box after an image upload.
