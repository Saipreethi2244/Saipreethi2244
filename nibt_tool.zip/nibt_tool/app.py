"""
NIBT Roll-up Dashboard  -  run with:  python -m streamlit run app.py
"""
import hashlib
import re

import pandas as pd
import streamlit as st

import engine as E

st.set_page_config(page_title="NIBT Roll-up Dashboard", page_icon="📊", layout="wide")

st.markdown(
    """
    <style>
    div[data-testid="stMetricValue"] {font-size: 2.1rem;}
    .block-container {padding-top: 2rem;}
    h2 {padding-top: 1.2rem;}
    </style>
    """,
    unsafe_allow_html=True,
)

fmt_money = "{:,.2f}"


def style_money(df, cols=None):
    cols = cols or [c for c in df.columns if pd.api.types.is_float_dtype(df[c])]
    return df.style.format({c: fmt_money for c in cols})


def total_row(df, label_col, num_cols):
    t = {label_col: "TOTAL"}
    for c in num_cols:
        t[c] = df[c].sum()
    return pd.concat([df, pd.DataFrame([t])], ignore_index=True)


# --------------------------------------------------------------------------
# cached wrappers
# --------------------------------------------------------------------------
@st.cache_data(show_spinner="Reading the workbook...")
def cached_load(data: bytes, sheet: str):
    return E.load_summary(data, sheet)


@st.cache_data(show_spinner="Reading image (OCR)...")
def cached_ocr(data: bytes):
    return E.ids_from_image(data)


IMG_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff")


def collect_account_list(kind: str, key: str):
    """Sidebar block: upload / paste a list of account numbers, review & edit it."""
    files = st.file_uploader(
        f"{kind} NIBT list - Excel, CSV or image (you can also click here and press Ctrl+V to paste a screenshot)",
        type=["xlsx", "xlsm", "xls", "csv", "png", "jpg", "jpeg", "bmp", "webp"],
        accept_multiple_files=True,
        key=f"{key}_files",
    )
    pasted = st.text_area(
        f"...or paste {kind} rows copied from Excel here",
        height=90,
        key=f"{key}_paste",
        placeholder="GL account<TAB>S1<TAB>S3 ...",
    )
    ids, notes = [], []
    for f in files or []:
        b = f.getvalue()
        name = f.name.lower()
        try:
            if name.endswith(IMG_EXT):
                if not E.ocr_available():
                    notes.append(f"{f.name}: image reading needs the optional OCR package (see README).")
                    continue
                got = cached_ocr(b)
            else:
                got = E.ids_from_table(b, name)
            ids += got
            notes.append(f"{f.name}: {len(got)} account numbers found")
        except Exception as ex:  # noqa: BLE001
            notes.append(f"{f.name}: could not be read ({ex})")
    if pasted.strip():
        got = E.ids_from_text(pasted)
        ids += got
        notes.append(f"Pasted text: {len(got)} account numbers found")
    for n in notes:
        st.caption(n)

    final = []
    if ids:
        sig = hashlib.md5("|".join(ids).encode()).hexdigest()[:8]
        edited = st.text_area(
            "Review / correct extracted account numbers (one per line)",
            value="\n".join(ids),
            height=120,
            key=f"{key}_edit_{sig}",
        )
        final = re.findall(r"\d{5,10}", edited)
    return final


# --------------------------------------------------------------------------
# sidebar
# --------------------------------------------------------------------------
with st.sidebar:
    st.header("1. Main Excel file")
    main = st.file_uploader("Upload the main workbook", type=["xlsx", "xlsm", "xls"], key="main")
    sheet = None
    if main is not None:
        names = E.list_sheets(main.getvalue())
        sheet = st.selectbox("Sheet to read", names, index=names.index(E.guess_sheet(names)))

    st.header("2. Account lists")
    st.caption("Optional. If nothing is uploaded, the Corporate / Associate Nibit columns of the main file are used. Associate Taxes needs an uploaded or pasted list.")
    with st.expander("Corporate NIBT list", expanded=False):
        corp_ids = collect_account_list("Corporate", "corp")
    with st.expander("Associate NIBT list", expanded=False):
        assoc_ids = collect_account_list("Associate", "assoc")
    with st.expander("Associate Taxes list", expanded=False):
        tax_ids = collect_account_list("Associate Taxes", "tax")

    st.header("3. Settings")
    fs_target = st.text_input("FS item to summarise", value="849TT")
    rm_text = st.text_input("Document type(s) to remove (comma separated)", value="ZG")
    tax_rate = st.number_input("Tax rate", min_value=0.0, max_value=1.0, value=0.21, step=0.01, format="%.2f",
                               help="Not applied anywhere yet - reserved for later.")
    dedupe = st.radio(
        "Duplicate accounts (Corporate / Associate)",
        options=list(E.DEDUPE_MODES.keys()),
        format_func=lambda k: E.DEDUPE_MODES[k].replace("849TT", fs_target or "target"),
        help="The same account appears under several FS items with the same value. "
        "The recommended rule counts it once.",
    )

# --------------------------------------------------------------------------
# main page
# --------------------------------------------------------------------------
st.title("📊 NIBT Roll-up Dashboard")

if main is None:
    st.info("⬅️ Upload the main Excel file in the sidebar to begin.")
    st.stop()

try:
    df, segs, raw, hdr = cached_load(main.getvalue(), sheet)
except Exception as ex:  # noqa: BLE001
    st.error(f"Could not read the file: {ex}")
    st.stop()

rm_types = [x.strip() for x in rm_text.split(",") if x.strip()]
res = E.analyse(
    df, segs, fs_target=fs_target.strip(), remove_doc_types=rm_types,
    corp_ids=corp_ids or None, assoc_ids=assoc_ids or None, tax_ids=tax_ids or None, dedupe=dedupe,
)
corp_src = f"Uploaded / pasted list ({len(set(corp_ids))} unique accounts)" if corp_ids else "Corporate Nibit column of main file"
assoc_src = f"Uploaded / pasted list ({len(set(assoc_ids))} unique accounts)" if assoc_ids else "Associate Nibit column of main file"

tax_src = f"Uploaded / pasted list ({len(set(tax_ids))} unique accounts)" if tax_ids else "No list supplied"

# ---------------- Step 1 ---------------------------------------------------
st.header("🧹 Step 1 - Document type removal")
c1, c2, c3, c4 = st.columns(4)
c1.metric("Rows in source", f"{len(df):,}")
c2.metric(f"Rows removed ({', '.join(rm_types) or '-'})", f"{len(res['removed']):,}")
c3.metric("Rows kept", f"{len(res['clean']):,}")
c4.metric("Document types in file", f"{df['DocType'].nunique():,}")

if len(res["removed"]) == 0:
    st.warning("No rows matched the document type(s) to remove.")
with st.expander("Removed rows - impact by FS item", expanded=False):
    if len(res["removed"]):
        st.dataframe(style_money(res["removed_by_fs"], segs), use_container_width=True, hide_index=True)
with st.expander("Removed rows - detail", expanded=False):
    q = st.text_input("Filter removed rows (any text)", key="q_removed")
    show = res["removed"][["Excel Row", "CU", "FS", "Account", "DocType", "DocDesc"] + segs]
    if q:
        show = show[show.astype(str).apply(lambda r: r.str.contains(q, case=False).any(), axis=1)]
    st.dataframe(style_money(show, segs), use_container_width=True, hide_index=True)
with st.expander("Document type distribution", expanded=False):
    dist = df.groupby("DocType").size().sort_values(ascending=False)
    st.bar_chart(dist)

# ---------------- Step 2: 849TT -------------------------------------------
st.header(f"🧮 Step 2a - {res['fs_target']} balance")
if res["fs_rows"].empty:
    st.error(f"No rows found for FS item '{res['fs_target']}'.")
a, b, c = st.columns(3)
a.metric(f"{res['fs_target']} rows combined", f"{len(res['fs_rows']):,}")
b.metric("Distinct accounts", f"{res['fs_rows']['Account'].nunique():,}")
c.metric("Total balance", f"{res['fs_ser'].sum():,.2f}")
left, right = st.columns([3, 2])
with left:
    t = E.seg_table(res["fs_ser"], f"{res['fs_target']} Balance ({len(res['fs_rows'])})", segs)
    st.dataframe(style_money(t, [t.columns[1]]), use_container_width=True, hide_index=True)
with right:
    st.bar_chart(res["fs_ser"])
with st.expander(f"{res['fs_target']} - balance by account", expanded=False):
    q = st.text_input("Filter account", key="q_fs")
    t = res["fs_acct"]
    if q:
        t = t[t["Account"].str.contains(q, case=False)]
    st.dataframe(style_money(t), use_container_width=True, hide_index=True)

# ---------------- Step 2: Corporate / Associate ---------------------------
def nibt_block(title, ids, src_label, ser, rows, acct_df, raw_n, key, flagged_label="Accounts flagged in file"):
    st.header(title)
    uniq = sorted(set(ids)) if ids else sorted(acct_df["Account"].tolist())
    found = set(acct_df["Account"])
    missing = [i for i in sorted(set(ids)) if i not in found] if ids else []
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Account numbers supplied" if ids else flagged_label, f"{len(ids) if ids else len(found):,}")
    m2.metric("Unique accounts", f"{len(uniq):,}")
    m3.metric("Found in main file", f"{len(found):,}")
    m4.metric("Rows after de-duplication", f"{len(rows):,}", delta=f"{len(rows) - raw_n:,} vs {raw_n:,} raw", delta_color="off")
    st.caption(f"Source of account list: {src_label}")
    left, right = st.columns([3, 2])
    with left:
        t = E.seg_table(ser, f"{title.split('-')[-1].strip()} ({len(found)})", segs)
        st.dataframe(style_money(t, [t.columns[1]]), use_container_width=True, hide_index=True)
    with right:
        st.bar_chart(ser)
    if missing:
        st.warning(f"{len(missing)} account(s) in your list were not found in the main file: {', '.join(missing[:30])}"
                   f"{' ...' if len(missing) > 30 else ''}")
    with st.expander("By account", expanded=False):
        q = st.text_input("Filter account", key=f"q_{key}")
        t = acct_df
        if q:
            t = t[t["Account"].str.contains(q, case=False)]
        st.dataframe(style_money(t), use_container_width=True, hide_index=True)


nibt_block("🏢 Step 2b - Corporate NIBT", corp_ids, corp_src, res["corp_ser"], res["corp_rows"],
           res["corp_acct"], res["corp_raw_n"], "corp")
nibt_block("🤝 Step 2c - Associate NIBT", assoc_ids, assoc_src, res["assoc_ser"], res["assoc_rows"],
           res["assoc_acct"], res["assoc_raw_n"], "assoc")

nibt_block("💷 Step 2d - Associate Taxes", tax_ids, tax_src, res["tax_ser"], res["tax_rows"],
           res["tax_acct"], res["tax_raw_n"], "tax", flagged_label="Accounts supplied")
if not tax_ids:
    st.caption("Upload or paste the Associate Taxes list in the sidebar to populate this section.")

# ---------------- Step 3: combined ----------------------------------------
st.header("🔗 Step 3 - Combined view")
comb = res["combined"]
num_cols = [c for c in comb.columns if c != "Segment"]
st.dataframe(style_money(total_row(comb, "Segment", num_cols), num_cols), use_container_width=True, hide_index=True)
st.caption("All NIBT = 849TT Balance - Corporate Items. Tax rate is not applied anywhere.")
st.bar_chart(comb.set_index("Segment")[["849TT Balance", "Corporate Items", "Associate NIBT", "All NIBT"]])

# ---------------- downloads -----------------------------------------------
st.header("⬇️ Download")
params = dict(
    remove_doc_types=rm_types or ["-"], rows_total=len(df), rows_removed=len(res["removed"]),
    corp_source=corp_src, assoc_source=assoc_src, tax_source=tax_src, source_name=main.name, sheet=sheet,
)
report = E.build_report(res, params)
d1, d2, d3 = st.columns(3)
d1.download_button(
    "📥 Download report (Excel)", report, file_name="NIBT_report.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", type="primary",
    use_container_width=True,
)
d2.download_button(
    "📥 Combined table (CSV)", comb.to_csv(index=False).encode(), file_name="NIBT_combined.csv",
    mime="text/csv", use_container_width=True,
)
with d3:
    if st.button(f"Prepare source file without {', '.join(rm_types) or 'removed rows'}", use_container_width=True):
        with st.spinner("Writing cleaned source file..."):
            st.session_state["clean_bytes"] = E.build_cleaned_source(raw, hdr, df, res["removed"]["Excel Row"])
    if "clean_bytes" in st.session_state:
        st.download_button(
            "📥 Download cleaned source (Excel)", st.session_state["clean_bytes"],
            file_name="Source_cleaned.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True,
        )
