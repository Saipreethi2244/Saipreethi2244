"""
engine.py - all calculation / file logic for the NIBT dashboard.
No Streamlit in here, so it can be tested on its own.
"""
import io
import re

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
NUM_FMT = '#,##0.00;(#,##0.00);"-"'
ID_RE = re.compile(r"(?<![\d.,-])\d{5,10}(?![\d]|[.,]\d)")


def norm_id(v):
    """Normalise an account number / code to a clean string."""
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    s = str(v).strip()
    if re.fullmatch(r"\d+\.0+", s):
        s = s.split(".")[0]
    return s


def _lab(v):
    return "" if v is None or (isinstance(v, float) and pd.isna(v)) else str(v).strip()


# --------------------------------------------------------------------------
# 1. read the main workbook ("Summary sheet")
# --------------------------------------------------------------------------
def list_sheets(data: bytes):
    return pd.ExcelFile(io.BytesIO(data)).sheet_names


def guess_sheet(names):
    for n in names:
        if "summary" in n.lower():
            return n
    return names[0]


def load_summary(data: bytes, sheet: str):
    """
    Returns (df, segs, raw, hdr)
      df   - tidy frame, one row per source row, numeric segment columns
      segs - list of segment names found in the header (S1, S3, S4, S8, # ...)
      raw  - the untouched sheet (header=None) used to write the cleaned source file
      hdr  - index of the header row inside raw
    """
    raw = pd.read_excel(io.BytesIO(data), sheet_name=sheet, header=None, dtype=object)

    hdr = None
    for i in range(min(len(raw), 40)):
        labs = [_lab(v).lower() for v in raw.iloc[i].tolist()]
        if "document type" in labs and "account number" in labs:
            hdr = i
            break
    if hdr is None:
        raise ValueError(
            "Could not find the header row (a row containing both 'Account Number' "
            "and 'Document Type'). Check you picked the right sheet."
        )

    labels = [_lab(v) for v in raw.iloc[hdr].tolist()]
    seg_labels = [_lab(v) for v in raw.iloc[hdr - 1].tolist()] if hdr >= 1 else [""] * len(labels)

    def nth(name, n=0):
        hits = [i for i, l in enumerate(labels) if l.lower() == name.lower()]
        return hits[n] if len(hits) > n else None

    c_cu, c_fs, c_fsn = nth("Consolidation Unit"), nth("FS Item"), nth("FS Item", 1)
    c_acct = nth("Account Number")
    c_corp, c_assoc = nth("Corporate Nibit"), nth("Associate Nibit")
    c_doc, c_docd = nth("Document Type"), nth("Document Type", 1)
    c_sub_cat, c_sub = nth("Subitem Category"), nth("Subitem")

    missing = [n for n, c in [("FS Item", c_fs), ("Account Number", c_acct), ("Document Type", c_doc)] if c is None]
    if missing:
        raise ValueError(f"Missing required column(s): {', '.join(missing)}")

    first_seg_col = (c_docd if c_docd is not None else c_doc) + 1
    seg_cols = []
    for ci in range(first_seg_col, len(labels)):
        name = seg_labels[ci] or labels[ci]
        if name and name.lower() not in ("segment", "measures"):
            seg_cols.append((ci, name))
    if not seg_cols:
        raise ValueError("No segment columns (S1, S3, S8, # ...) found to the right of Document Type.")

    body = raw.iloc[hdr + 1:]
    out = pd.DataFrame(index=body.index)

    def col(ci):
        return body.iloc[:, ci].map(norm_id) if ci is not None else ""

    out["CU"] = col(c_cu)
    out["FS"] = col(c_fs)
    out["FS Name"] = col(c_fsn)
    out["Account"] = col(c_acct)
    out["Corporate Flag"] = col(c_corp)
    out["Associate Flag"] = col(c_assoc)
    out["SubCat"] = col(c_sub_cat)
    out["Sub"] = col(c_sub)
    out["DocType"] = col(c_doc)
    out["DocDesc"] = col(c_docd)
    segs = []
    for ci, name in seg_cols:
        out[name] = pd.to_numeric(body.iloc[:, ci], errors="coerce").fillna(0.0)
        segs.append(name)
    out.insert(0, "Excel Row", out.index + 1)
    out = out[out["FS"] != ""]  # drop blank trailing rows
    return out.reset_index(drop=True), segs, raw, hdr


# --------------------------------------------------------------------------
# 2. account lists for Corporate / Associate NIBT (excel, csv, pasted text, image)
# --------------------------------------------------------------------------
def ids_from_text(text: str):
    """First account-looking number (5-10 digits) on every line, in order."""
    ids = []
    for line in str(text).splitlines():
        m = ID_RE.search(line)
        if m:
            ids.append(m.group(0))
    return ids


def ids_from_table(data: bytes, filename: str):
    name = filename.lower()
    if name.endswith((".csv", ".txt")):
        frames = {"csv": pd.read_csv(io.BytesIO(data), header=None, dtype=object, sep=None, engine="python")}
    else:
        frames = pd.read_excel(io.BytesIO(data), sheet_name=None, header=None, dtype=object)
    best = []
    for df in frames.values():
        for c in df.columns:
            vals = [norm_id(v) for v in df[c].tolist()]
            hits = [v for v in vals if re.fullmatch(r"\d{5,10}", v)]
            if len(hits) > len(best):
                best = hits
    return best


_OCR = None


def ocr_available():
    try:
        import rapidocr_onnxruntime  # noqa: F401
        return True
    except Exception:
        return False


def ids_from_image(data: bytes):
    """OCR an image and return the account numbers found (one per visual row)."""
    global _OCR
    from rapidocr_onnxruntime import RapidOCR  # optional dependency

    if _OCR is None:
        _OCR = RapidOCR()
    result, _ = _OCR(data)
    if not result:
        return []
    items = []
    for box, text, _score in result:
        ys = [p[1] for p in box]
        xs = [p[0] for p in box]
        items.append((sum(ys) / 4, min(xs), max(ys) - min(ys), str(text)))
    items.sort()
    rows, cur, cur_y, cur_h = [], [], None, None
    for y, x, h, t in items:  # cluster boxes that sit on the same visual line
        if cur_y is None or abs(y - cur_y) <= max(cur_h, h) * 0.6:
            cur.append((x, t))
            cur_y = y if cur_y is None else (cur_y + y) / 2
            cur_h = h if cur_h is None else max(cur_h, h)
        else:
            rows.append(cur)
            cur, cur_y, cur_h = [(x, t)], y, h
    if cur:
        rows.append(cur)
    return ids_from_text("\n".join("  ".join(t for _, t in sorted(r)) for r in rows))


# --------------------------------------------------------------------------
# 3. the analysis
# --------------------------------------------------------------------------
DEDUPE_MODES = {
    "unique": "One row per Account + Unit + Subitem + Document Type (recommended)",
    "target_fs": "Only rows under the 849TT FS item",
    "none": "No de-duplication (sum every row)",
}


def _dedupe(df, mode, fs_target):
    if mode == "target_fs":
        return df[df["FS"].str.upper() == fs_target.upper()]
    if mode == "unique":
        return df.drop_duplicates(subset=["CU", "Account", "SubCat", "Sub", "DocType"], keep="first")
    return df


def _by_account(df, segs):
    if df.empty:
        return pd.DataFrame(columns=["Account"] + segs + ["Total"])
    g = df.groupby("Account", sort=True)[segs].sum().reset_index()
    g["Total"] = g[segs].sum(axis=1)
    return g


def _series(df, segs):
    s = df[segs].sum() if len(df) else pd.Series(0.0, index=segs)
    return s.astype(float)


def analyse(df, segs, *, fs_target="849TT", remove_doc_types=("ZG",),
            corp_ids=None, assoc_ids=None, tax_ids=None, dedupe="unique"):
    rm = {x.strip().upper() for x in remove_doc_types if x.strip()}
    is_removed = df["DocType"].str.upper().isin(rm)
    removed, clean = df[is_removed], df[~is_removed]

    # 849TT - every row of the target FS item, all added together by segment
    fs_rows = clean[clean["FS"].str.upper() == fs_target.upper()]
    fs_ser = _series(fs_rows, segs)

    # Corporate / Associate - match on the Account Number column
    if corp_ids:
        corp_mask = clean["Account"].isin(set(corp_ids))
    else:
        corp_mask = clean["Corporate Flag"] != ""
    if assoc_ids:
        assoc_mask = clean["Account"].isin(set(assoc_ids))
    else:
        assoc_mask = clean["Associate Flag"] != ""
    # Associate Taxes: only an uploaded / pasted list (the main file has no flag column for it)
    if tax_ids:
        tax_mask = clean["Account"].isin(set(tax_ids))
    else:
        tax_mask = pd.Series(False, index=clean.index)
    corp_raw, assoc_raw, tax_raw = clean[corp_mask], clean[assoc_mask], clean[tax_mask]
    corp_rows = _dedupe(corp_raw, dedupe, fs_target)
    assoc_rows = _dedupe(assoc_raw, dedupe, fs_target)
    tax_rows = _dedupe(tax_raw, dedupe, fs_target)

    corp_ser, assoc_ser, tax_ser = _series(corp_rows, segs), _series(assoc_rows, segs), _series(tax_rows, segs)

    comb = pd.DataFrame({"Segment": segs})
    comb["849TT Balance"] = fs_ser.values
    comb["Corporate Items"] = corp_ser.values
    comb["Associate NIBT"] = assoc_ser.values
    comb["Associate Taxes"] = tax_ser.values
    comb["All NIBT"] = comb["849TT Balance"] - comb["Corporate Items"]

    return dict(
        removed=removed, clean=clean, fs_rows=fs_rows, fs_ser=fs_ser,
        corp_rows=corp_rows, corp_ser=corp_ser, corp_raw_n=len(corp_raw),
        assoc_rows=assoc_rows, assoc_ser=assoc_ser, assoc_raw_n=len(assoc_raw),
        tax_rows=tax_rows, tax_ser=tax_ser, tax_raw_n=len(tax_raw), tax_acct=_by_account(tax_rows, segs),
        corp_acct=_by_account(corp_rows, segs), assoc_acct=_by_account(assoc_rows, segs),
        fs_acct=_by_account(fs_rows, segs), combined=comb, segs=segs,
        fs_target=fs_target, dedupe=dedupe,
        removed_by_fs=(removed.groupby("FS")[segs].sum().assign(Rows=removed.groupby("FS").size())
                       .reset_index() if len(removed) else pd.DataFrame()),
    )


def seg_table(ser, label, segs):
    t = pd.DataFrame({"Segment": segs, label: ser.values})
    return pd.concat([t, pd.DataFrame([{"Segment": "TOTAL", label: float(ser.sum())}])], ignore_index=True)


# --------------------------------------------------------------------------
# 4. downloads
# --------------------------------------------------------------------------
_HDR_FILL = PatternFill("solid", start_color="1F4E78")
_TOT_FILL = PatternFill("solid", start_color="DDEBF7")
_THIN = Side(style="thin", color="BFBFBF")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)


def _hdr(ws, row, headers, col=1):
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=col + i, value=h)
        c.font = Font(name="Arial", bold=True, color="FFFFFF", size=10)
        c.fill = _HDR_FILL
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = _BORDER


def _put(ws, row, col, val, bold=False, fmt=None, fill=None, color="000000"):
    c = ws.cell(row=row, column=col, value=val)
    c.font = Font(name="Arial", size=10, bold=bold, color=color)
    c.border = _BORDER
    if fmt:
        c.number_format = fmt
    if fill:
        c.fill = fill
    return c


def _autowidth(ws, minw=12, maxw=48):
    widths = {}
    for row in ws.iter_rows():
        for c in row:
            if c.value is not None:
                widths[c.column] = max(widths.get(c.column, 0), len(str(c.value)) if not isinstance(c.value, float) else 16)
    for k, w in widths.items():
        ws.column_dimensions[get_column_letter(k)].width = max(minw, min(maxw, w + 2))


def _detail_sheet(wb, title, ser_title, acct_df, segs, rows_df):
    ws = wb.create_sheet(title)
    ws["A1"] = ser_title
    ws["A1"].font = Font(name="Arial", bold=True, size=12)
    hdr = ["Account"] + segs + ["Total"]
    _hdr(ws, 3, hdr)
    r = 4
    for _, rec in acct_df.iterrows():
        _put(ws, r, 1, rec["Account"])
        for j, s in enumerate(segs):
            _put(ws, r, 2 + j, float(rec[s]), fmt=NUM_FMT)
        _put(ws, r, 2 + len(segs), f"=SUM(B{r}:{get_column_letter(1 + len(segs))}{r})", fmt=NUM_FMT)
        r += 1
    last = r - 1
    _put(ws, r, 1, "TOTAL", bold=True, fill=_TOT_FILL)
    for j in range(len(segs) + 1):
        L = get_column_letter(2 + j)
        f = f"=SUM({L}4:{L}{last})" if last >= 4 else 0
        _put(ws, r, 2 + j, f, bold=True, fmt=NUM_FMT, fill=_TOT_FILL)
    r += 3
    ws.cell(row=r, column=1, value="Source rows used").font = Font(name="Arial", bold=True, size=11)
    cols = ["Excel Row", "CU", "FS", "Account", "DocType", "DocDesc"] + segs
    _hdr(ws, r + 1, cols)
    rr = r + 2
    for rec in rows_df[cols].itertuples(index=False):
        for j, v in enumerate(rec):
            _put(ws, rr, 1 + j, v if not isinstance(v, float) else float(v), fmt=NUM_FMT if j >= 6 else None)
        rr += 1
    ws.freeze_panes = "B4"
    _autowidth(ws)


def build_report(res, params: dict) -> bytes:
    segs = res["segs"]
    n = len(segs)
    wb = Workbook()

    # ---- Combined (live formulas) --------------------------------------
    ws = wb.active
    ws.title = "Combined"
    ws["A1"] = "NIBT roll-up - 849TT / Corporate / Associate"
    ws["A1"].font = Font(name="Arial", bold=True, size=14)
    heads = ["Segment", "849TT Balance", "Corporate Items", "Associate NIBT", "Associate Taxes", "All NIBT"]
    _hdr(ws, 4, heads)
    ws.row_dimensions[4].height = 32
    for i, s in enumerate(segs):
        r = 5 + i
        _put(ws, r, 1, s)
        _put(ws, r, 2, float(res["fs_ser"][s]), fmt=NUM_FMT, color="0000FF")
        _put(ws, r, 3, float(res["corp_ser"][s]), fmt=NUM_FMT, color="0000FF")
        _put(ws, r, 4, float(res["assoc_ser"][s]), fmt=NUM_FMT, color="0000FF")
        _put(ws, r, 5, float(res["tax_ser"][s]), fmt=NUM_FMT, color="0000FF")
        _put(ws, r, 6, f"=B{r}-C{r}", fmt=NUM_FMT)
    tr = 5 + n
    _put(ws, tr, 1, "TOTAL", bold=True, fill=_TOT_FILL)
    for c in range(2, 7):
        L = get_column_letter(c)
        _put(ws, tr, c, f"=SUM({L}5:{L}{tr - 1})", bold=True, fmt=NUM_FMT, fill=_TOT_FILL)
    ws.cell(row=tr + 2, column=1, value="Blue = values taken from the source file; black = formulas. All NIBT = 849TT Balance - Corporate Items.").font = Font(
        name="Arial", italic=True, size=9, color="7F7F7F")
    ws.freeze_panes = "B5"
    _autowidth(ws, minw=14)
    ws.column_dimensions["A"].width = 26

    # ---- detail sheets ---------------------------------------------------
    _detail_sheet(wb, "849TT", f"{res['fs_target']} - FS item rows combined by segment (after document-type removal)",
                  res["fs_acct"], segs, res["fs_rows"])
    _detail_sheet(wb, "Corporate NIBT", "Corporate NIBT - by unique Account Number",
                  res["corp_acct"], segs, res["corp_rows"])
    _detail_sheet(wb, "Associate NIBT", "Associate NIBT - by unique Account Number",
                  res["assoc_acct"], segs, res["assoc_rows"])
    _detail_sheet(wb, "Associate Taxes", "Associate Taxes - by unique Account Number",
                  res["tax_acct"], segs, res["tax_rows"])

    # ---- removed rows ----------------------------------------------------
    wr = wb.create_sheet("Removed rows")
    wr["A1"] = f"Rows removed from the source (Document Type in: {', '.join(params['remove_doc_types'])})"
    wr["A1"].font = Font(name="Arial", bold=True, size=12)
    cols = ["Excel Row", "CU", "FS", "FS Name", "Account", "DocType", "DocDesc"] + segs
    _hdr(wr, 3, cols)
    r = 4
    for rec in res["removed"][cols].itertuples(index=False):
        for j, v in enumerate(rec):
            _put(wr, r, 1 + j, v if not isinstance(v, float) else float(v), fmt=NUM_FMT if j >= 7 else None)
        r += 1
    wr.freeze_panes = "A4"
    _autowidth(wr)

    # ---- assumptions -----------------------------------------------------
    wa = wb.create_sheet("Assumptions")
    items = [
        ("Source file", params.get("source_name", "")),
        ("Sheet read", params.get("sheet", "")),
        ("Document types removed", ", ".join(params["remove_doc_types"])),
        ("Rows in source", params["rows_total"]),
        ("Rows removed", params["rows_removed"]),
        ("Rows kept", params["rows_total"] - params["rows_removed"]),
        ("FS item summarised", res["fs_target"]),
        ("Corporate accounts source", params["corp_source"]),
        ("Associate accounts source", params["assoc_source"]),
        ("Associate Taxes accounts source", params["tax_source"]),
        ("De-duplication rule", DEDUPE_MODES[res["dedupe"]]),
        ("Tax rate", "Not applied - to be specified later"),
        ("All NIBT definition", "849TT Balance - Corporate Items"),
    ]
    _hdr(wa, 1, ["Item", "Value"])
    for i, (k, v) in enumerate(items, start=2):
        _put(wa, i, 1, k, bold=True)
        _put(wa, i, 2, v)
    wa.column_dimensions["A"].width = 30
    wa.column_dimensions["B"].width = 80

    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def build_cleaned_source(raw: pd.DataFrame, hdr: int, df: pd.DataFrame, removed_rows) -> bytes:
    """Source sheet with the removed rows taken out, header rows preserved."""
    drop = set(int(x) - 1 for x in removed_rows)  # excel row -> raw index
    wb = Workbook(write_only=True)
    ws = wb.create_sheet("Summary sheet (cleaned)")

    def clean(v):
        return None if v is None or (isinstance(v, float) and pd.isna(v)) else v

    for i in range(len(raw)):
        if i <= hdr or i not in drop:
            ws.append([clean(v) for v in raw.iloc[i].tolist()])
    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()
